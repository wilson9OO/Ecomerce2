from django.shortcuts import render, redirect
from .models import Product, Cart, Category

def product_list(request):
    categories = Category.objects.all()
    category_id = request.GET.get('category')
    
    if category_id:
        products = Product.objects.filter(category_id=category_id)
    else:
        products = Product.objects.all()
    
    return render(request, 'store/product_list.html', {'products': products, 'categories': categories})

def cart(request):
    cart_items = Cart.objects.all()
    total_price = sum(item.product.price * item.quantity for item in cart_items)
    return render(request, 'store/cart.html', {'cart_items': cart_items, 'total_price': total_price})

def add_to_cart(request, product_id):
    product = Product.objects.get(id=product_id)
    cart_item, created = Cart.objects.get_or_create(product=product)
    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('cart')

def remove_from_cart(request, cart_id):
    Cart.objects.get(id=cart_id).delete()
    return redirect('cart')

def checkout(request):
    cart_items = Cart.objects.all()
    total_price = sum(item.product.price * item.quantity for item in cart_items)

    if request.method == "POST":
        
        cart_items.delete()
        return render(request, 'store/checkout_success.html', {'total_price': total_price})

    return render(request, 'store/checkout.html', {'cart_items': cart_items, 'total_price': total_price})


def shop(request):
    products = Product.objects.all()
    return render(request, 'store/shop.html', {'products': products})

def about(request):
    return render(request, 'store/about.html')




def shop(request):
    query = request.GET.get('q') 
    if query:
        products = Product.objects.filter(name__icontains=query) 
    else:
        products = Product.objects.all() 

    context = {
        'products': products,
        'query': query,
    }
    return render(request, 'store/shop.html', context)  



def category_view(request, category_name):
    products = Product.objects.filter(category__name=category_name)  
    return render(request, 'store/shop.html', {'products': products, 'selected_category': category_name})

def laptops(request):
    return render(request, 'store/laptops.html')

def iphones(request):
    return render(request, 'store/iphones.html')


def laptops(request):
    context = {'hide_bottom_section': True}
    return render(request, 'store/laptops.html', context)

def iphones(request):
    context = {'hide_bottom_section': True}
    return render(request, 'store/iphones.html', context)

def category_products(request, category_name):
    products = Product.objects.filter(category__name=category_name) 
    category = Category.objects.get(name=category_name)  
    return render(request, 'category.html', {'products': products, 'category': category})




