from django.contrib.auth import views as auth_views
from django.urls import path
from . import views
from .views import category_products






urlpatterns = [
    path('', views.product_list, name='product_list'),
    path('shop/', views.shop, name='shop'),
    path('about/', views.about, name='about'),
    path('cart/', views.cart, name='cart'),
    path('add_to_cart/<int:product_id>/', views.add_to_cart, name='add_to_cart'),
    path('remove_from_cart/<int:cart_id>/', views.remove_from_cart, name='remove_from_cart'),
    path('checkout/', views.checkout, name='checkout'),
    path('login/', auth_views.LoginView.as_view(template_name='store/login.html'), name='login'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/'), name='logout'),
    path('logout/', auth_views.LogoutView.as_view(next_page='/admin/login/'), name='logout'),
    path('category/<str:category_name>/', views.category_view, name='category'),
    path('laptops/', views.laptops, name='laptops'),
    path('iphones/', views.iphones, name='iphones'),
    path('category/<str:category_name>/', category_products, name='category_products'),


    

    

]
